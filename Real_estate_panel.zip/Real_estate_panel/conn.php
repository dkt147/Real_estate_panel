<?php

$con = mysqli_connect("localhost","root","","real_estate_4");

if(!$con)
{
    echo "Failed";
}



?>